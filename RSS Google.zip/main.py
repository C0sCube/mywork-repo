from datetime import datetime
import os
import time

from app.constants import get_log_dir, get_sch_config
from app.logger import setup_logger, set_global_logger
from app.mailer import Mailer
from app.nse_rss import news_run_handler
from app.schedular import scheduler_loop


PROGRAM_NAME = "500 Company News Google API"

def program_handler(logger, mailer: Mailer):
    start_time = datetime.now()
    date_str = start_time.strftime('%d-%m-%y')
    send_mail =  mailer.SEND_MAIL

    logger.info(f"Starting scheduled run at {date_str} {start_time.strftime('%H:%M')}")
    
    if send_mail:
        mailer.start_mail(program=f"{PROGRAM_NAME}: {date_str}", dev=True)

    try:
        zip_path = news_run_handler()
        duration = (datetime.now() - start_time).total_seconds()

        if zip_path and os.path.exists(zip_path):
            logger.info(f"Run completed in {duration:.2f} seconds.")
            if send_mail:
                mailer.end_mail(
                    program=f"{PROGRAM_NAME}: {date_str}",
                    attachments=[zip_path],
                    dev=False
                )
        else:
            logger.warning("Zip file missing. Skipping end mail.")
            if send_mail:
                mailer.fatal_error_mail(
                    program=f"{PROGRAM_NAME}: {date_str}",
                    custom_msg="Zip file not found after run.",
                    error_message="No zip file was generated.",
                    dev=True
                )

    except Exception as e:
        logger.exception("Fatal error during program_handler")
        if send_mail:
            mailer.fatal_error_mail(
                program=f"{PROGRAM_NAME}: {date_str}",
                custom_msg="Zip file not found after run.",
                error_message="No zip file was generated.",
                dev=True
            )


def main():
    logger = setup_logger(
        "watcher",
        log_dir=get_log_dir(),
        log_level=12
    )
    set_global_logger(logger)
    mailer = Mailer()

    logger.info("Running Program to fetch News via Google API.")

    try:
        sch_data = get_sch_config()
        # Pass dependencies to the scheduled function via lambda/closure
        scheduler_loop(
            logger,
            lambda: program_handler(logger, mailer),
            sch_data["schedule_days"],
            sch_data["schedule_times"]
        )

    except Exception as e:
        # This is a truly unexpected top-level failure
        logger.exception("Unexpected error in main")
        date_str = datetime.now().strftime('%d-%m-%y')
        if mailer.send_mail:
            mailer.fatal_error_mail(
                program=f"{PROGRAM_NAME}: {date_str}",
                custom_msg="Zip file not found after run.",
                error_message="No zip file was generated.",
                dev=True
            )


if __name__ == "__main__":
    main()
    