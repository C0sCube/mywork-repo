import os, re , unidecode, ftfy, requests
from datetime import datetime
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import urllib3
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from app.logger import setup_logger
from app.constants import (KEYWORDS_TO_CHECK,CUTOFF_DATE, BASE_URL, LOG_PATH,OUTPUT_PATH)

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

all_keywords = KEYWORDS_TO_CHECK
logger = setup_logger("nse_news_log", log_dir=LOG_PATH)


def fetch_news(company, keyword):
    try:
        query = f"{company} {keyword} when:1.25d".replace(" ", "%20")
        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/115.0.0.0 Safari/537.36"
            ),
            "Accept-Language": "en-US,en;q=0.9",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
            "Connection": "keep-alive"
        }
        url = f"{BASE_URL}/search?q={query}&hl=en-IN&gl=IN&ceid=IN:en"
        resp = requests.get(url, timeout=40, verify=False, headers=headers)
        resp.encoding = 'utf-8'
        print(f"Returned: {resp.status_code}")
        soup = BeautifulSoup(resp.text, "html.parser")

        results = []
        for article in soup.select("article"):
            data = article.find_all('a')
            for x_data in data:
                href_link = x_data.get('href')
                full_url = urljoin(BASE_URL, href_link) if href_link else None
                raw_headline = x_data.text.strip()
                if not raw_headline:
                    continue
                headline = clean_headline(raw_headline)
                source_tag = article.select_one("div.vr1PYe")
                source = source_tag.get_text(strip=True) if source_tag else None

                time_tag = article.find("time")
                published = time_tag["datetime"] if time_tag and time_tag.has_attr("datetime") else None
                if published:
                    pub_date = datetime.fromisoformat(published.replace("Z", "+00:00"))
                    if pub_date < CUTOFF_DATE:
                        continue

                results.append({"Company": company, "Keyword": keyword,"Headline": headline,"Source": source,"Link": full_url,"Published": published})
        return results
    except Exception as e:
        logger.error(f"Error fetching news for {company} + {keyword}: {e}")
        return []

def clean_headline(text: str) -> str:
    try:
        cleaned_str = re.sub(r"[\r\n\t]|&nbsp;?", "", text, flags=re.IGNORECASE).strip()
        cleaned_str = re.sub(r'[\x00-\x1F\x7F-\x9F]', '', cleaned_str)
        cleaned_str = unidecode.unidecode(cleaned_str)
        try:
            fixed = cleaned_str.encode('latin1').decode('utf-8')
        except Exception:
            fixed = cleaned_str
        return ftfy.fix_text(fixed)

    except Exception:
        return text.strip()

def process_company(company):
    company_news = []
    for kw in all_keywords:
        logger.info(f"   → {company}: Searching keyword: {kw}")
        news_items = fetch_news(company, kw)
        company_news.extend(news_items)
    logger.info(f"   ✔ Finished {company}, collected {len(company_news)} items.")
    return company_news

def runner(companies, csv_path):
    write_header = not os.path.exists(csv_path)
    logger.info(f"\n Starting parallel processing for {len(companies)} companies...\n")
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(process_company, company): company for company in companies}
        for idx, future in enumerate(as_completed(futures), start=1):
            company = futures[future]
            try:
                result = future.result()
                if result:
                    df = pd.DataFrame(result)
                else:
                    df = pd.DataFrame([{
                        "Company": company,
                        "Keyword": "",
                        "Headline": "No news found",
                        "Source": "",
                        "Link": "",
                        "Published": ""
                    }])

                df.to_csv(csv_path, mode='a', header=write_header, index=False)
                write_header = False  # Only write header once

                if result:
                    logger.info(f"[{idx}/{len(companies)}] ✅ {company} appended → {csv_path} ({len(result)} records)")
                else:
                    logger.warning(f"[{idx}/{len(companies)}] ⚠️ No news found for {company} — placeholder added")

            except Exception as e:
                logger.error(f"[{idx}/{len(companies)}] ❌ Error processing {company}: {e}")

if __name__ == "__main__":
    
    try:
        path = r"List of Companies.xlsx"
        df = pd.read_excel(path)
        company_names = df['Company name'].dropna().tolist()
        
        output_dir = OUTPUT_PATH
        csv_path = os.path.join(output_dir, "all_companies.csv")
        runner(company_names,csv_path)
    
    except Exception as e:
        logger.critical(f"Error During Runtime.")





 