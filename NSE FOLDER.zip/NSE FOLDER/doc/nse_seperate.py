import os, re, unidecode, ftfy, requests, urllib3
from datetime import datetime
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from app.logger import setup_logger
from app.constants import KEYWORDS_TO_CHECK, CUTOFF_DATE, BASE_URL, LOG_PATH

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

logger = setup_logger("nse_news_log", log_dir=LOG_PATH)
all_keywords = KEYWORDS_TO_CHECK

def clean_headline(text: str) -> str:
    try:
        cleaned = re.sub(r"[\r\n\t]|&nbsp;?", "", text, flags=re.IGNORECASE).strip()
        cleaned = re.sub(r'[\x00-\x1F\x7F-\x9F]', '', cleaned)
        cleaned = unidecode.unidecode(cleaned)
        try:
            fixed = cleaned.encode('latin1').decode('utf-8')
        except Exception:
            fixed = cleaned
        return ftfy.fix_text(fixed)
    except Exception:
        return text.strip()

def fetch_news(company, keyword):
    try:
        query = f"{company} {keyword} when:1.25d".replace(" ", "%20")
        url = f"{BASE_URL}/search?q={query}&hl=en-IN&gl=IN&ceid=IN:en"
        resp = requests.get(url, timeout=40, verify=False)
        resp.encoding = 'utf-8'
        soup = BeautifulSoup(resp.text, "html.parser")

        results = []
        for article in soup.select("article"):
            for link_tag in article.find_all('a'):
                href = link_tag.get('href')
                full_url = urljoin(BASE_URL, href) if href else None
                raw_headline = link_tag.text.strip()
                if not raw_headline:
                    continue
                headline = clean_headline(raw_headline)
                source_tag = article.select_one("div.vr1PYe")
                source = source_tag.get_text(strip=True) if source_tag else None
                time_tag = article.find("time")
                published = time_tag["datetime"] if time_tag and time_tag.has_attr("datetime") else None
                if published:
                    pub_date = datetime.fromisoformat(published.replace("Z", "+00:00"))
                    if pub_date < CUTOFF_DATE:
                        continue
                results.append({
                    "Company": company,
                    "Keyword": keyword,
                    "Headline": headline,
                    "Source": source,
                    "Link": full_url,
                    "Published": published
                })
        return results
    except Exception as e:
        logger.error(f"Error fetching news for {company} + {keyword}: {e}", exc_info=True)
        return []

def process_company(company):
    company_news = []
    for kw in all_keywords:
        logger.info(f"→ {company}: Searching keyword: {kw}")
        news_items = fetch_news(company, kw)
        company_news.extend(news_items)
    logger.info(f"✔ Finished {company}, collected {len(company_news)} items.")
    return company_news

def runner(companies, output_dir):
    logger.info(f"\nStarting parallel processing for {len(companies)} companies...\n")
    with ThreadPoolExecutor(max_workers=20) as executor:
        futures = {executor.submit(process_company, company): company for company in companies}
        for idx, future in enumerate(as_completed(futures), start=1):
            company = futures[future]
            try:
                result = future.result()
                if result:
                    df = pd.DataFrame(result)
                else:
                    df = pd.DataFrame([{
                        "Company": company,
                        "Keyword": "",
                        "Headline": "No news found",
                        "Source": "",
                        "Link": "",
                        "Published": ""
                    }])
                clean_name = company.replace(" ", "_").replace("/", "_")
                excel_path = os.path.join(output_dir, f"{clean_name}.xlsx")
                df.to_excel(excel_path, index=False, engine="openpyxl")

                if result:
                    logger.info(f"[{idx}/{len(companies)}] ✅ {company} saved → {excel_path} ({len(result)} records)")
                else:
                    logger.warning(f"[{idx}/{len(companies)}] ⚠️ No news found for {company} — placeholder saved")
            except Exception as e:
                logger.error(f"[{idx}/{len(companies)}] ❌ Error processing {company}: {e}", exc_info=True)

if __name__ == "__main__":
    try:
        input_path = "List of Companies.xlsx"
        df = pd.read_excel(input_path)
        company_names = df['Company name'].dropna().tolist()
        output_dir = "all_data"
        os.makedirs(output_dir, exist_ok=True)
        runner(company_names, output_dir)
    except Exception as e:
        logger.critical("Error During Runtime", exc_info=True)