import smtplib, traceback
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from pathlib import Path
from datetime import datetime


from app.constants import load_mail_data
from app.logger import get_global_logger

class Mailer:
    def __init__(self, server='172.17.0.126', port=25, 
                sender='Kaustubh.Keny@cogencis.com', 
                recipients=["kaustubh.keny@cogencis.com"], 
                dev_recipients = ["kaustubh.keny@cogencis.com"],
                cc=None, bcc=None, logger=None):
        
        try:
            mail_config = load_mail_data()
            server = mail_config.get("server", server)
            port = mail_config.get("port", port)
            sender = mail_config.get("sender", sender)
            recipients = mail_config.get("normal_recipients", recipients)
            dev_recipients = mail_config.get("dev_recipients", dev_recipients)
            cc = mail_config.get("cc", cc)
            bcc = mail_config.get("bcc", bcc)               
        except FileNotFoundError:
            print("paths.json file not found. Using default values.")
        
        self.SERVER = server
        self.PORT = port
        self.FROM = sender or "noreply@example.com"
        self.RECPTS = recipients if isinstance(recipients, list) else [recipients] if recipients else []
        self.DEVRECPTS = dev_recipients if isinstance(dev_recipients, list) else [dev_recipients] if dev_recipients else []
        self.CC = cc if isinstance(cc, list) else [cc] if cc else []
        self.BCC = bcc if isinstance(bcc, list) else [bcc] if bcc else []
        
        self.logger = get_global_logger()


    def start_mail(self, program, data=None,attachments=None, dev = True):
        #here data is a int
        try:
            subject = f"{program} — Execution Started"
            body = f"""
            <html>
                <body>
                    <p>Hello Team,</p>
                    <p>The program <b>{program}</b> has <b>started</b>.</p>
                    <p>Regards,<br>Kaustubh</p>
                </body>
            </html>
            """
            msg = self.construct_mail(subject=subject, body_html=body, attachments = attachments, dev=dev)
            self.send_mail(msg, dev=dev)
        
        except Exception as e:
            self.logger.error(f"Start Mail not Sent.")
            self.logger.error(f"{type(e).__name__}: {e}")
            self.logger.error(traceback.format_exc())
   
    def end_mail(self, program, data=None,attachments=None, dev = False):
        try:
            subject = f"{program} — Execution Completed"
            body = f"""
            <html>
                <body>
                    <p>Hello Team,</p>
                    <p>The program <b>{program}</b> has <b>completed</b> execution.<br>
                    The Files are attatched as zip.</p>
                    <p>NOTE: *THIS IS AN AUTOMATED MAIL*</p>
                    <p>Regards,</p>
                </body>
            </html>
            """
            msg = self.construct_mail(subject=subject, body_html=body, attachments = attachments, dev=dev)
            self.send_mail(msg, dev=dev)
        except Exception as e:
            self.logger.error(f"End Mail not Sent.")
            self.logger.error(f"{type(e).__name__}: {e}")
            self.logger.error(traceback.format_exc())
            raise

    def fatal_error_mail(self, program,custom_msg = None, error_message=None, exception_obj=None, attachments=None, dev = True):
        try:
            subject = f"{program} Fatal Error Occurred"
            error_details = f"<pre>{traceback.format_exc()}</pre>" if exception_obj else ""
            body = f"""
            <html>
                <body>
                    <p>Hello Team,</p>
                    <p>The program <b>{program}</b> encountered a <b>fatal error</b>.</p>
                    <p>Error Comment: <b>{custom_msg}</b></p>
                    <p>Error Message: <b>{error_message}</b></p>
                    {error_details}
                    <p>Please check logs and investigate.</p>
                    <p>Regards,<br>System</p>
                </body>
            </html>
            """
            msg = self.construct_mail(subject=subject, body_html=body, attachments=attachments, dev=dev)
            self.send_mail(msg, dev=dev)
        except Exception as e:
            self.logger.error("Fatal Error Mail not sent.")
            self.logger.error(f"{type(e).__name__}: {e}")
            self.logger.error(traceback.format_exc())
    
    def default_body(self):
        return """
        <html>
            <body>
                <p>Hello Team,</p>
                <p>This is Default Mail Message.</p>
                <p>Regards,<br>System</p>
            </body>
        </html>
        """
    
    def send_custom(self, subject, body_html=None, body_text=None):
        msg = self.construct_mail(subject=subject, body_html=body_html, body_text=body_text)
        self.send_mail(msg)
    
    def construct_mail(self, subject, body_html=None, body_text=None, attachments = None, dev = True):
        msg = MIMEMultipart("alternative")
        
        recpts = self.DEVRECPTS if dev else self.RECPTS
        msg["From"] = self.FROM
        msg["To"] = ", ".join(recpts)
        if not dev and self.CC:
            msg["Cc"] = ", ".join(self.CC)
        msg["Subject"] = f"{subject} - {datetime.now().strftime('%Y-%m-%d')}"

        if body_text: msg.attach(MIMEText(body_text, "plain"))
        if body_html: msg.attach(MIMEText(body_html, "html"))
        else: msg.attach(MIMEText(self.default_body(), "html"))
        
        
        if attachments:
            for file_path in attachments:
                path = Path(file_path)
                if path.exists():
                    with open(path, "rb") as f:
                        part = MIMEApplication(f.read(), Name=path.name)
                        part['Content-Disposition'] = f'attachment; filename="{path.name}"'
                        msg.attach(part)
                else:
                    self.logger.warning(f"Attachment not found: {file_path}")

        return msg

    def send_mail(self, msg, dev = True):
        try:
            recpts = self.DEVRECPTS if dev else self.RECPTS
            cc = self.CC if not dev else []
            bcc = self.BCC if not dev else []
            all_recipients = recpts + cc + bcc
            with smtplib.SMTP(self.SERVER, self.PORT) as server:
                server.send_message(msg, from_addr=self.FROM, to_addrs=all_recipients)
            self.logger.info("Email sent successfully.")
        except Exception as e:
            self.logger.error(f"Failed to send email: {e}")
