import os, feedparser, traceback, time, re, pytz
from datetime import timezone
import pandas as pd
from html import unescape
from datetime import datetime, timedelta
from urllib.parse import quote_plus
from app.logger import get_global_logger
from app.zip_connector import zip_file
from app.constants import KEYWORDS_TO_CHECK, get_output_path, company_path
from concurrent.futures import ThreadPoolExecutor, as_completed
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

analyzer = SentimentIntensityAnalyzer()
IST = pytz.timezone('Asia/Kolkata')

#================= FETCH =================


def fetch_company_news(company, ticker, keywords=KEYWORDS_TO_CHECK, cutoff_hours=30):
    """
    Fetch recent RSS news for a company across multiple keywords,
    normalize company name, filter by cutoff time, and inject ticker.
    """
    results = []
    logger = get_global_logger()
    cutoff_date = datetime.now(IST) - timedelta(hours=cutoff_hours)

    try:
        normalied_company = normalize_company_name(company)

        for kw in keywords:
            logger.info(f" → {company}: Searching keyword: {kw}")
            query = f"\"{normalied_company}\"+\"{kw}\""
            encoded_query = quote_plus(query)

            rss_url = f"https://news.google.com/rss/search?q={encoded_query}&hl=en-IN&gl=IN&ceid=IN:en"
            feed = feedparser.parse(rss_url)

            for entry in feed.entries:
                pub_date = datetime.fromtimestamp(
                    time.mktime(entry.published_parsed), tz=timezone.utc
                )
                if pub_date < cutoff_date:
                    continue

                source = getattr(entry, "source", {}).get("title", "")
                raw_title = unescape(entry.title)
                cleaned_title = re.sub(fr"(.+?)\s*-\s*{re.escape(source)}$", r"\1", raw_title)

                results.append({
                    "Company": company,
                    "Ticker": ticker,
                    "Keyword": kw,
                    "Headline": re.sub(r"[^\x20-\x7E]", "", cleaned_title),
                    "Source": source,
                    "Link": entry.link,
                    "Published": pub_date.isoformat()
                })

            time.sleep(0.04)  # polite delay

        logger.info(f" ✔ Finished {company}, collected {len(results)} items.")
        return results

    except Exception as e:
        logger.error(f"Error fetching RSS for {company}: {e}")
        return []
    
def runner(company_data, csv_path):
    """
    Run threaded RSS fetch for multiple companies and append results to a CSV.
    
    Args:
        company_data (dict): Mapping of {company_name: ticker_symbol}.
        csv_path (str): Path to output CSV file.
    """
    logger = get_global_logger()
    companies = list(company_data.keys())

    # canonical columns we always want in the CSV
    canonical_cols = ["Company", "Ticker", "Keyword", "Headline", "Source", "Link", "Published"]

    # ensure header exists
    if not os.path.exists(csv_path):
        pd.DataFrame(columns=canonical_cols).to_csv(csv_path, index=False)

    logger.info(f"\nStarting threaded RSS fetch for {len(companies)} companies...\n")

    with ThreadPoolExecutor(max_workers=18) as executor:
        futures = {
            executor.submit(fetch_company_news, company, company_data[company]): (company, company_data[company])
            for company in companies
        }

        for idx, future in enumerate(as_completed(futures), start=1):
            company, ticker = futures[future]
            try:
                result = future.result()

                if result: df = pd.DataFrame(result)
                else:
                    # fallback row if no news found
                    df = pd.DataFrame([{
                        "Company": company,
                        "Ticker": ticker,
                        "Keyword": "",
                        "Headline": "No news found",
                        "Source": "",
                        "Link": "",
                        "Published": ""
                    }])

                # enforce canonical column order
                df = df.reindex(columns=canonical_cols)

                # append to CSV
                df.to_csv(csv_path, mode="a", header=False, index=False)

                logger.info(f"[{idx}/{len(companies)}] {company} appended → {csv_path} ({len(df)} records)")

            except Exception as e:
                logger.error(f"[{idx}/{len(companies)}] Error processing {company}: {e}")
                # optional: append a "failed" row for consistency
                fail_df = pd.DataFrame([{
                    "Company": company,
                    "Ticker": ticker,
                    "Keyword": "",
                    "Headline": f"Error: {e}",
                    "Source": "",
                    "Link": "",
                    "Published": ""
                }])
                fail_df.to_csv(csv_path, mode="a", header=False, index=False)



#================= HELPERS =================

def normalize_company_name(company: str) -> str:
    suffixes = ["limited", "ltd","ltd."]
    words = company.split()
    if words[-1].lower() in suffixes:
        words = words[:-1]
    return " ".join(words)

def get_sentiment(text):
    score = analyzer.polarity_scores(str(text))
    compound = score['compound']
    if compound >= 0.05: return "Positive"
    elif compound <= -0.05: return "Negative"
    else: return "Neutral"          

def find_keywords_contextual(text):
    text_lower = str(text).lower()
    sentiment = analyzer.polarity_scores(text_lower)["compound"]
    found = []

    STRICT_KEYWORDS = {"fir", "fire", "fine", "law", "ban", "fraud", "accident"}
    PHRASE_KEYWORDS = [kw for kw in KEYWORDS_TO_CHECK if len(kw.split()) > 1]
    
    if sentiment > -0.05: return ""

    for kw in KEYWORDS_TO_CHECK:
        base_kw = kw.lower()
        if base_kw in STRICT_KEYWORDS:
            # FIR special context rule
            if base_kw == "fir":
                if re.search(r"\bFIR (filed|registered|against|lodged)\b", text, re.IGNORECASE): found.append(kw)
                    
            elif base_kw == "fire":
                if re.search(r"\bfire (broke|break|at|in)\b", text_lower): found.append(kw)
            else:
                if re.search(rf"\b{kw}\b", text): found.append(kw)
            continue

        if kw in PHRASE_KEYWORDS:
            if re.search(rf"\b{re.escape(base_kw)}\b", text_lower):
                found.append(kw)
            continue

        if len(base_kw) > 12:
            fuzzy_core = re.sub(r"[^a-z]", "", base_kw[:10])
            if re.search(fuzzy_core, text_lower):
                found.append(kw)
            continue

        if re.search(rf"\b{re.escape(base_kw)}\b", text_lower):
            found.append(kw)

    return "; ".join(sorted(set(found))) if found else ""

def company_in_headline(headline, company, aliases=None):
    text_lower = headline.lower()
    company_clean = normalize_company_name(company).lower()
    aliases = aliases or []
    all_terms = [company_clean] + [a.lower() for a in aliases]
    for term in all_terms:
        pattern = rf"\b{re.escape(term)}(\s+(limited|ltd|pvt|private|plc))?\b"
        if re.search(pattern, text_lower, re.IGNORECASE):   
            return "Yes"
    return "No"


#================= AGGREGATE =================  

def enrich_news(df: pd.DataFrame):
    # Sentiment and keyword detection
    df["Sentiment"] = df["Headline"].apply(get_sentiment)
    df["Keywords_Found"] = df["Headline"].apply(find_keywords_contextual)
    df["Company_Match"] = df.apply( lambda row: company_in_headline(row["Headline"], row["Company"]), axis=1)

    # Sorting helpers
    sentiment_order = {"Negative": 0, "Neutral": 1, "Positive": 2}
    df["Sentiment_Order"] = df["Sentiment"].map(sentiment_order)
    df["Company_Order"] = df["Company_Match"].map({"Yes": 0, "No": 1})
    df = df.sort_values(
        by=["Sentiment_Order", "Company_Order", "Company"], #"Keyword_Order",
        ascending=[True, True, True]
    ).drop(columns=["Sentiment_Order", "Company_Order"])
    return df

def aggregate_news(raw_csv_path):
    df = pd.read_csv(raw_csv_path)
    base_columns = df.columns.to_list()

    aggregated = df.groupby(["Company", "Link"]).agg({
        "Keyword": lambda x: "; ".join(sorted(set(x))),
        "Ticker":"first",
        "Headline": "first",
        "Source": "first",
        "Published": "min"
    }).reset_index()

    mention_counts = df.groupby(["Company", "Link"]).size().reset_index(name="Mentions")
    aggregated = aggregated.merge(mention_counts, on=["Company", "Link"], how="left")

    aggregated = aggregated[base_columns + ["Mentions"]]
    aggregated.sort_values(by=["Company", "Mentions"], inplace=True)
    return aggregated


#================= HANDLER =================

def news_run_handler():
    
    logger = get_global_logger()
    today = datetime.now()
    timestamp = today.strftime("%d%m%yT%H%M")
    output_path = get_output_path()
    
    try: 
        df = pd.read_excel(company_path())
        df = df.dropna(subset=["Company name", "Ticker"])

        # Take first 20
        companies = df["Company name"].tolist()
        tickers = df["Ticker"].tolist()
        company_data = dict(zip(companies, tickers))

        
        csv_path = os.path.join(output_path,f"500_company_news_{timestamp}.csv")
        runner(company_data,csv_path)
        
        #aggregate
        agg_path = os.path.join(output_path,f"Aggregated_News_{timestamp}.csv")
        df1 = aggregate_news(csv_path)
        df1.to_csv(agg_path, index=False)
        
        #enrich + sentiment + keyword search
        logger.info("Aggregating + Sentimental Analysis + Keyword")
        final_path = os.path.join(output_path,f"Final_500_News{timestamp}.csv")
        df2 = enrich_news(df1)
        df2.to_csv(final_path, index=False)        
        
        #zip + 
        logger.info("Successfully Ran Program. Proceeding to zip..")
        zip_path = os.path.join(output_path,f"NSE_NEWS_{timestamp}.zip")
        zip_file(final_path,zip_path)
        
        if not os.path.exists(zip_path) or os.path.getsize(zip_path) == 0:
            logger.warning("Compression failed: ZIP file not found or empty.")
            return None

        logger.info(f"ZIP file created successfully: {zip_path}")
        return zip_path
        
    except Exception as e:
        logger.error(f"News Handler Error: {type(e).__name__}: {e}")
        logger.debug(traceback.format_exc())
        
        return None
