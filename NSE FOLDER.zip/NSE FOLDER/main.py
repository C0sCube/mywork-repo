from datetime import datetime, timedelta
import os, time,traceback

from app.constants import getoutput_dir, schedule_details, create_dir, PROGRAM_NAME
from app.logger import setup_logger, set_global_logger
from app.mailer import Mailer
from app.nse_rss import news_run_handler

output_dir = getoutput_dir()
schedule_detail = schedule_details()
SCHEDULE_DAYS = [d.lower() for d in schedule_detail.get("schedule_days", [])]
SCHEDULE_TIMES = schedule_detail.get("schedule_times", [])
SEND_MAIL = schedule_detail.get("send_mail", False)

def init_logger():
    today = datetime.now().strftime("%Y-%m-%d")
    log_dir = create_dir(output_dir, "log", today)
    logger = setup_logger("nse_newslog", log_dir=log_dir)
    set_global_logger(logger)
    return logger

def run_once(logger, mailer, send_mail=False):
    today_str = datetime.now().strftime('%d-%m-%y')
    logger.info(f"Starting scheduled run at {today_str} {datetime.now().strftime('%H:%M')}")

    start_time = datetime.now()
    try:
        if send_mail:
            mailer.start_mail(program=f"{PROGRAM_NAME}: {today_str}", dev=True)

        zip_path = news_run_handler()
        duration = (datetime.now() - start_time).total_seconds()

        if zip_path and os.path.exists(zip_path):
            logger.info(f"Run completed in {duration:.2f} seconds.")
            if send_mail:
                mailer.end_mail(
                    program=f"{PROGRAM_NAME}: {today_str}",
                    attachments=[zip_path],
                    dev=False
                )
        else:
            logger.warning("Zip file missing. Skipping end mail.")
            if send_mail:
                mailer.fatal_error_mail(
                    program=f"{PROGRAM_NAME}: {today_str}",
                    custom_msg="Zip file not found after run.",
                    error_message="No zip file was generated.",
                    dev=True
                )

    except Exception as e:
        logger.error(f"Fatal error: {type(e).__name__}: {e}")
        logger.debug(traceback.format_exc())
        if send_mail:
            mailer.fatal_error_mail(
                program=f"{PROGRAM_NAME}: {today_str}",
                custom_msg="Fatal error during run.",
                error_message=str(e),
                exception_obj=e,
                dev=True
            )

def schedule_loop(logger, mailer, send_mail=False):
    last_log_date = datetime.now().date()
    executed_today = set()

    while True:
        now = datetime.now()
        current_day = now.strftime("%a").lower()[:3]  # e.g., 'mon'
        current_time = now.strftime("%H%M")

        # Rotate logger daily
        if now.date() != last_log_date:
            logger = init_logger()
            last_log_date = now.date()
            executed_today.clear()
            logger.info(f"Logger rotated for {now.strftime('%Y-%m-%d')}")

        # Find next scheduled time
        if current_day in SCHEDULE_DAYS:
            future_times = [t for t in SCHEDULE_TIMES if t not in executed_today and t > current_time]
            if future_times:
                next_sched_str = min(future_times)
                next_sched_dt = datetime.strptime(next_sched_str, "%H%M").replace(
                    year=now.year, month=now.month, day=now.day
                )
                time_left = next_sched_dt - now
                hours, remainder = divmod(time_left.seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                logger.info(f"Time left for next scheduled run: {hours}h {minutes}m {seconds}s")

        # Check if today is a scheduled day and time matches
        for sched_time in SCHEDULE_TIMES:
            if current_day in SCHEDULE_DAYS and current_time == sched_time and sched_time not in executed_today:
                run_once(logger, mailer, send_mail=send_mail)
                executed_today.add(sched_time)

        time.sleep(30)  # Check every 30 seconds


if __name__ == "__main__":
    logger = init_logger()
    mailer = Mailer()
    logger.info("Running Program to fetch News via Google API.")
    logger.info(f"Scheduler for: {SCHEDULE_DAYS} & time(s)={SCHEDULE_TIMES}")

    try:
        schedule_loop(logger, mailer, send_mail=SEND_MAIL)

    except KeyboardInterrupt:
        logger.warning(f"Scheduler interrupted at {datetime.now().strftime('%d-%m-%y %H:%M')}")
        if SEND_MAIL:
            mailer.fatal_error_mail(
                program=f"{PROGRAM_NAME}: {datetime.now().strftime('%d-%m-%y')}",
                custom_msg="Keyboard Interrupt",
                error_message="User manually stopped the scheduler.",
                dev=True
            )
    
    except Exception as e:
        logger.critical(f"Unexpected error: {type(e).__name__}: {e}")
        logger.debug(traceback.format_exc())
        if SEND_MAIL:
            mailer.fatal_error_mail(
                program=f"{PROGRAM_NAME}: {datetime.now().strftime('%d-%m-%y')}",
                custom_msg="Unexpected error in scheduler loop.",
                error_message=str(e),
                exception_obj=e,
                dev=True
            )




# from datetime import datetime, timedelta
# import time
# import traceback
# import os

# from app.constants import (
#     SCHEDULE_INTERVAL, SCHEDULE_START_TIME, SCHEDULE_MODE,
#     OUTPUT_DIR, PROGRAM_NAME, SEND_MAIL, create_dir
# )
# from app.logger import setup_logger, set_global_logger
# from app.mailer import Mailer
# from app.nse_rss import news_run_handler


# def wait_until_start(start_time):
#     """Pause execution until the configured start time."""
#     now = datetime.now()
#     today_start = datetime.combine(now.date(), start_time)
#     if now > today_start:
#         today_start += timedelta(days=1)

#     wait_seconds = (today_start - now).total_seconds()
#     logger.info(f"Waiting {int(wait_seconds)} seconds until start at {today_start}")
#     time.sleep(wait_seconds)


# def run_once(send_mail=False):
#     """Execute a single full cycle: fetch, zip, mail."""
#     today = datetime.now()
#     logger.info(f"Starting scheduled run at {today.strftime('%d-%m-%y %H:%M')}")

#     mailer = Mailer()
#     start_time = datetime.now()

#     try:
#         if send_mail:
#             mailer.start_mail(program=f"{PROGRAM_NAME}: {today.strftime('%d-%m-%y')}", dev=True)

#         # Run the main handler
#         zip_path = news_run_handler()
#         duration = (datetime.now() - start_time).total_seconds()

#         # Check if zip file was created properly
#         if zip_path and os.path.exists(zip_path):
#             logger.info(f"Run completed successfully in {duration:.2f} seconds.")
#             if send_mail:
#                 mailer.end_mail(
#                     program=f"{PROGRAM_NAME}: {today.strftime('%d-%m-%y')}",
#                     attachments=[zip_path], dev=False
#                 )
#                 logger.info("End mail sent successfully.")
#         else:
#             logger.warning("Zip file was not created or is missing. Skipping end mail.")
#             if send_mail:
#                 mailer.fatal_error_mail(
#                     program=f"{PROGRAM_NAME}: {today.strftime('%d-%m-%y')}",
#                     custom_msg="Zip file not found after run completion.",
#                     error_message="No zip file was generated by the handler.",
#                     dev=True
#                 )

#     except Exception as e:
#         logger.error(f"Fatal error during run: {type(e).__name__}: {e}")
#         logger.debug(traceback.format_exc())

#         if send_mail:
#             mailer.fatal_error_mail(
#                 program=f"{PROGRAM_NAME}: {today.strftime('%d-%m-%y')}",
#                 custom_msg="Fatal error during scheduled run.",
#                 error_message=str(e),
#                 exception_obj=e,
#                 dev = True
#             )


# def schedule_loop(send_mail=False):
#     """Run scheduler in either fixed or interval mode."""
#     while True:
#         run_once(send_mail=send_mail)
#         now = datetime.now()

#         if SCHEDULE_MODE == "fixed":
#             next_run = datetime.combine(now.date(), SCHEDULE_START_TIME)
#             if now > next_run:
#                 next_run += timedelta(days=1)
#             wait_seconds = (next_run - now).total_seconds()
#             logger.info(f"Next run scheduled at {next_run.strftime('%d-%m-%y %H:%M')} (fixed mode). Waiting {int(wait_seconds)} seconds.")
#         else:
#             next_run = now + timedelta(seconds=SCHEDULE_INTERVAL)
#             wait_seconds = SCHEDULE_INTERVAL
#             logger.info(f"Next run scheduled at {next_run.strftime('%d-%m-%y %H:%M')} (interval mode). Waiting {int(wait_seconds)} seconds.")

#         time.sleep(wait_seconds)


# if __name__ == "__main__":
#     today = datetime.now()
#     logger = setup_logger("nse_newslog",log_dir=create_dir(OUTPUT_DIR, "log", today.strftime("%Y%m%d")))
#     set_global_logger(logger)

#     try:
#         logger.info(f"Scheduler initialized at {today.strftime('%d-%m-%y %H:%M')} in {SCHEDULE_MODE.upper()} mode.")
#         wait_until_start(SCHEDULE_START_TIME)
#         schedule_loop(send_mail=SEND_MAIL)
#     except KeyboardInterrupt:
#         logger.warning(f"Scheduler interrupted by user at {datetime.now().strftime('%d-%m-%y %H:%M')}")
#         if SEND_MAIL:
#             mailer = Mailer()
#             mailer.fatal_error_mail(
#                 program=f"{PROGRAM_NAME}: {today.strftime('%d-%m-%y')}",
#                 custom_msg="Keyboard Interrupt",
#                 error_message="User manually stopped the scheduler.",
#                 dev=True
#             )
#     except Exception as e:
#         logger.critical(f"Unexpected error in scheduler loop: {type(e).__name__}: {e}")
#         logger.debug(traceback.format_exc())
#         if SEND_MAIL:
#             mailer = Mailer()
#             mailer.fatal_error_mail(
#                 program=f"{PROGRAM_NAME}: {today.strftime('%d-%m-%y')}",
#                 custom_msg="Unexpected error in scheduler loop.",
#                 error_message=str(e),
#                 exception_obj=e,
#                 dev = True
#             )
