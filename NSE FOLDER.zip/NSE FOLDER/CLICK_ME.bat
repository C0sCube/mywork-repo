@echo off

title Google RSSFeed NewFetch
REM Change to the directory where your project and virtual environment are located
cd D:\Developers\Kaustubh\NSE_NEWS_PROGRAM

REM Activate the virtual environment
call .venv\Scripts\activate.bat

REM Run your Python script
python main.py

pause