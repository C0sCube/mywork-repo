import os, feedparser, traceback, time, re, pytz
from datetime import timezone
import pandas as pd
from html import unescape
from datetime import datetime, timedelta
from urllib.parse import quote_plus
from app.logger import get_global_logger
from app.zip_connector import zip_file
from app.constants import get_output_dir, get_company_path, get_api_config
from concurrent.futures import ThreadPoolExecutor, as_completed
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer #type: ignore

analyzer = SentimentIntensityAnalyzer()
logger = get_global_logger()
IST = pytz.timezone('Asia/Kolkata')

#================= FETCH =================

def fetch_company_news(company, ticker, keywords:list, api_config:dict):
    """
    Fetch recent RSS news for a company across multiple keywords,
    normalize company name, filter by cutoff time, and inject ticker.
    """
    results = []
    cutoff_date = datetime.now(IST) - timedelta(hours=api_config['cutoff_hours'])
    normalized_company = normalize_company(company)
    base_url = api_config["rss_url"]
    delay = api_config["api_fetch_delay"]
    data_cols = api_config["data_cols"]
    
    try:

        for kw in keywords:
            logger.info(f" → {company}: Searching keyword: {kw}")
            encoded_query = quote_plus(f"\"{normalized_company}\"+\"{kw}\"")

            rss_url = f"{base_url}?q={encoded_query}&hl=en-IN&gl=IN&ceid=IN:en"
            feed = feedparser.parse(rss_url)

            for entry in feed.entries:
                
                if not hasattr(entry, "published_parsed") or not entry.published_parsed:
                    continue

                
                pub_date = datetime.fromtimestamp(
                    time.mktime(entry.published_parsed), tz=timezone.utc
                )
                if pub_date < cutoff_date:
                    continue

                source = getattr(entry, "source", {}).get("title", "")
                title = unescape(getattr(entry, "title", ""))
                link = getattr(entry, "link", "")

                title = unescape(title)
                # cleaned_title = re.sub(fr"(.+?)\s*-\s*{re.escape(source)}$", r"\1", raw_title)
                # cleaned_title = re.sub(r"[^\x20-\x7E]", "", cleaned_title)
                results.append({
                    k:v for k,v in 
                    zip(
                        data_cols,
                        [company,ticker,kw,title, source,link,pub_date.isoformat()]
                    )
                })

            time.sleep(delay)  # polite delay

        logger.info(f" ✔ Finished {company}, collected {len(results)} items.")
        return results

    except Exception as e:
        logger.error(f"Error fetching RSS for {company}: {e}")
        return []
   
def thread_executor(csv_path:str, program_data:dict):
    """
    Run threaded RSS fetch for multiple companies and append results to a CSV.
    
    Args:
        company_data (dict): Mapping of {company_name: ticker_symbol}.
        csv_path (str): Path to output CSV file.
    """
    company_data = program_data["company_data"]
    companies = list(company_data.keys())
    keywords = program_data["keywords"]
    api_config = program_data["api_config"]
    data_cols = api_config["data_cols"]

    #thread
    thread_config = api_config["thread_config"]


    if not os.path.exists(csv_path):
        pd.DataFrame(columns=data_cols).to_csv(csv_path, index=False)

    logger.info(f"\nStarting threaded for {len(companies)} companies...\n")

    with ThreadPoolExecutor(max_workers=thread_config["max_workers"]) as executor:
        futures = {
            executor.submit(
                fetch_company_news, company, company_data[company],keywords,api_config
            ): (
                company, company_data[company],keywords,api_config
            )
            for company in companies
        }

        for idx, future in enumerate(as_completed(futures), start=1):
            company, ticker = futures[future]
            try:
                result = future.result()

                if result: 
                    df = pd.DataFrame(result)
                else:
                    df = pd.DataFrame([{k:v for k,v in zip(data_cols,[company,ticker,"","NO News","","",""])}])

                df = df.reindex(columns=data_cols)
                df.to_csv(csv_path, mode="a", header=False, index=False)
                logger.info(f"[{idx}/{len(companies)}] {company} appended → {csv_path} ({len(df)} records)")

            except Exception as e:
                logger.error(f"[{idx}/{len(companies)}] Error processing {company}: {e}")
                fail_df = pd.DataFrame([{k:v for k,v in zip(data_cols,[company,ticker,"",f'Error: {e}',"","",""])}])
                fail_df.to_csv(csv_path, mode="a", header=False, index=False)

#================= HELPERS =================

def normalize_company(company: str) -> str:
    pattern = r'\s+(private\s+limited|pvt\.?\s*ltd\.?|limited|ltd\.?)$'
    company = company.strip()

    while re.search(pattern, company, flags=re.IGNORECASE):
        company = re.sub(pattern, '', company, flags=re.IGNORECASE)

    return company.strip().lower()

def get_sentiment(text):
    score = analyzer.polarity_scores(str(text))
    compound = score['compound']
    if compound >= 0.05: return "Positive"
    elif compound <= -0.05: return "Negative"
    else: return "Neutral"
    
def is_company_in_headline(headline, company, aliases=None):
    text_lower = headline.lower()
    company_clean = normalize_company(company)
    aliases = aliases or []
    all_terms = [company_clean] + [a.lower() for a in aliases]
    for term in all_terms:
        pattern = rf"\b{re.escape(term)}(\s+(private\s*limited|pvt\.?\s*ltd\.?|ltd\.?|pvt\.?|plc|limited))?\b"
        if re.search(pattern, text_lower, re.IGNORECASE):   
            return "Yes"
    return "No"

def find_keywords_contextual(text, keyword_meta,sentiment_label:str):
    text_lower = str(text).lower()

    if sentiment_label == "Positive":
        return ""
    
    found = []
    strict_keywords = keyword_meta["strict_keywords"]
    phrase_keywords = keyword_meta["phrase_keywords"]
    compiled_patterns = keyword_meta["compiled_patterns"]

    for kw, pattern in compiled_patterns.items():
        base_kw = kw.lower()

        # --- FIR (simplified, high-confidence keyword) ---
        if base_kw == "fir":
            if re.search(r"\bfirs?\b", text_lower):
                found.append(kw)
            continue

        # --- FIRE (contextual physical fire only) ---
        if base_kw == "fire":
            if re.search(r"\bfire\b", text_lower) and \
               re.search(r"\b(factory|plant|warehouse|unit|facility|site|broke|erupts|accident)\b", text_lower):
                found.append(kw)
            continue

        # --- Strict ambiguous keywords ---
        if base_kw in strict_keywords:
            if pattern.search(text_lower):
                found.append(kw)
            continue

        # --- Phrase keywords ---
        if kw in phrase_keywords:
            if pattern.search(text_lower):
                found.append(kw)
            continue

        # --- Normal keyword ---
        if pattern.search(text_lower):
            found.append(kw)

    return "; ".join(sorted(set(found))) if found else ""

def get_data():
    file_path = get_company_path()

    df = pd.read_excel(file_path, sheet_name="METADATA")

    df1 = df[["Company", "Ticker"]].dropna().copy()
    df2 = df["Keywords"].dropna().copy()

    company_data = dict(zip(df1["Company"].tolist(),
                            df1["Ticker"].tolist()))

    keywords = df2.tolist()

    # --- Keyword Classification ---
    strict_keywords = {"fine", "law", "ban", "fraud", "accident"}
    phrase_keywords = [kw for kw in keywords if len(kw.split()) > 1]

    compiled_patterns = {
        kw: re.compile(rf"\b{re.escape(kw.lower())}\b")
        for kw in keywords
    }

    api_config = get_api_config()

    return {
        "api_config": api_config,
        "company_data": company_data,
        "keywords": keywords,
        "keyword_meta": {
            "strict_keywords": strict_keywords,
            "phrase_keywords": phrase_keywords,
            "compiled_patterns": compiled_patterns
        }
    }


#================= AGGREGATE =================  

def enrich_news(csv_path: str, save_path: str, keyword_meta: dict):
    df = pd.read_csv(csv_path)

    df["Sentiment"] = df["Headline"].apply(get_sentiment)
    df["Keywords_Found"] = df.apply(
        lambda row: find_keywords_contextual( row["Headline"],keyword_meta,row["Sentiment"]),
        axis=1
    )
    df["Company_Match"] = df.apply(lambda row: is_company_in_headline(row["Headline"], row["Company"]), axis=1)

    df["Sentiment_Order"] = df["Sentiment"].map({"Negative": 0, "Neutral": 1, "Positive": 2})
    df["Company_Order"] = df["Company_Match"].map({"Yes": 0, "No": 1})

    df = df.sort_values(
        by=["Sentiment_Order", "Company_Order", "Company"],
        ascending=[True, True, True]
    ).drop(columns=["Sentiment_Order", "Company_Order"])

    df.to_csv(save_path, index=False)
    return df

def aggregate_news(csv_path,save_path):
    df = pd.read_csv(csv_path)
    base_columns = df.columns.to_list()

    aggregated = df.groupby(["Company", "Link"]).agg({
        "Keyword": lambda x: "; ".join(sorted(set(x))),
        "Ticker":"first",
        "Headline": "first",
        "Source": "first",
        "Published": "min"
    }).reset_index()

    mention_counts = df.groupby(["Company", "Link"]).size().reset_index(name="Mentions")
    aggregated = aggregated.merge(mention_counts, on=["Company", "Link"], how="left")

    aggregated = aggregated[base_columns + ["Mentions"]]
    aggregated.sort_values(by=["Company", "Mentions"], inplace=True)
    
    aggregated.to_csv(save_path, index=False)
    return aggregated


#================= HANDLER =================

def news_run_handler():
    try:
        timestamp = datetime.now().strftime("%d%m%yT%H%M")
        output_path = get_output_dir()
        program_data = get_data()

        
        csv_path = os.path.join(output_path,f"COMPANY_NEWS_{timestamp}.csv")
        thread_executor(csv_path,program_data)
        
        #aggregate + sentiment
        agg_path = os.path.join(output_path,f"AGG_COMPANY_NEWS_{timestamp}.csv")
        aggregate_news(csv_path,agg_path)

        final_path = os.path.join(output_path,f"FINAL_PUBLISH_NEWS_{timestamp}.csv")
        enrich_news(agg_path,final_path,program_data["keyword_meta"])
              
        
        #zip + 
        logger.info("Proceeding to zip..")
        zip_path = os.path.join(output_path,f"NEWS_FOR_NSE_VIA_COGENCIS_{timestamp}.zip")
        zip_file(final_path,zip_path)
        
        if not os.path.exists(zip_path) or os.path.getsize(zip_path) == 0:
            logger.warning("Compression failed: ZIP file not found or empty.")
            return None

        logger.info(f"ZIP file created successfully: {zip_path}")
        return zip_path
        
    except Exception as e:
        logger.error(f"News Handler Error: {type(e).__name__}: {e}")
        logger.error(traceback.format_exc())
        
        return None

