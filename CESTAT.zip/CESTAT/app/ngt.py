import re, time
import requests
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
import pandas as pd
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from app.logger import get_global_logger
from app.utils import Helper


class NGT:

    def __init__(self):
        self.session = requests.Session()
        self.logger = get_global_logger()
        self.utils = Helper()

    def normalize_name(self, text: str) -> str:
        text = "" if text is None else str(text)

        text = re.sub(r"\b(limted|limlited|limited|ltd)\.?\b", "ltd", text, flags=re.IGNORECASE)
        text = re.sub(r"\b(private|pvt)\.?\b", "pvt", text, flags=re.IGNORECASE)
        text = re.sub(r"\bco\.?\b", "co", text, flags=re.IGNORECASE)

        text = text.replace("&amp;", "&").replace("&amp;amp;", "&")
        text = re.sub(r"\band\b", "&", text, flags=re.IGNORECASE)

        text = re.sub(r"\s+", " ", text).strip()
        return text.lower()

    def get_payload(self, payload, captcha, zone_type, order_by, date_format):
        from_dt, to_dt = self.utils.generate_dates(date_format)

        payload.update({
            "zone_type": str(zone_type),
            "from_date": from_dt,
            "to_date": to_dt,
            "order_by": str(order_by),
            "captcha_input": captcha
        })

        return payload

    def get_captcha(self, url:str):
     
        resp = self.session.get(url, verify=False)
        resp.raise_for_status()

        with open("captcha.png", "wb") as f:
            f.write(resp.content)

        print("Captcha saved as captcha.png")
        return input("Enter captcha: ")

    def extract_rows(self, soup, base_url):
        table = soup.find("table")

        if not table:
            self.logger.warning("No table found")
            return []

        rows = table.find_all("tr")
        if len(rows) < 2:
            return []

        headers = [th.get_text(strip=True) for th in rows[0].find_all(["th", "td"])]

        results = []

        for row in rows[1:]:
            cols = row.find_all("td")
            if not cols:
                continue

            row_data = [c.get_text(strip=True) for c in cols]

            link_tag = row.find("a")
            link = None

            if link_tag and link_tag.get("href"):
                link = link_tag["href"]
                if not link.startswith("http"):
                    link = base_url + link

            row_dict = dict(zip(headers, row_data))
            row_dict["link"] = link

            results.append(row_dict)

        return results

    def get_total_pages(self, soup, selector):
        pages = []

        for a in soup.select(selector):
            href = a.get("href")
            if not href:
                continue

            match = re.search(r"page=(\d+)", href)
            if match:
                pages.append(int(match.group(1)))

        return max(pages) if pages else 1

    def fetch_pages(self, payload, headers, data_url, selector, base_url):
        all_results = []

        payload_page = payload.copy()
        payload_page["page"] = 1

        resp = self.session.post(data_url, data=payload_page, headers=headers, verify=False)
        resp.raise_for_status()

        if "Invalid Captcha" in resp.text:
            raise RuntimeError("Captcha failed")

        soup = BeautifulSoup(resp.text, "html.parser")

        page_results = self.extract_rows(soup, base_url)
        all_results.extend(page_results)

        self.logger.info(f"Page 1 → {len(page_results)} rows")

        total_pages = self.get_total_pages(soup, selector)
        self.logger.info(f"Total pages: {total_pages}")

        for page in range(2, total_pages + 1):
            payload_page = payload.copy()
            payload_page["page"] = page

            self.logger.info(f"Fetching page {page}")

            resp = self.session.post(data_url, data=payload_page, headers=headers, verify=False)
            resp.raise_for_status()

            soup = BeautifulSoup(resp.text, "html.parser")

            page_results = self.extract_rows(soup, base_url)
            all_results.extend(page_results)

            self.logger.info(f"Page {page} → {len(page_results)} rows")

        return all_results

    def get_data(self, config, retires = 10):

        all_results = []

        base_url = config["base_url"]
        data_url = config["data_url"]
        captcha_url = config["captcha_url"]
        selector = config["pagination"]
        base_payload = config["api_payload"]
        benches = config["benches"]
        order_types = config["order_type"]
        headers = config.get("headers", {"User-Agent": "Mozilla/5.0"})
        date_format = config.get("date_format", "%d/%m/%Y")

        try:
            captcha = self.get_captcha(captcha_url)

            for order_name, order_val in order_types.items():
                for bench_name, bench_val in benches.items():

                    payload = self.get_payload(
                        base_payload.copy(),
                        captcha,
                        bench_val,
                        order_val,
                        date_format
                    )

                    self.logger.info(f"[POST] bench={bench_name}, order={order_name}")

                    results = self.fetch_pages(
                        payload,
                        headers,
                        data_url,
                        selector,
                        base_url
                    )

                    for r in results:
                        r["Zonal Bench"] = bench_name
                        r["Order Type"] = order_name

                    all_results.extend(results)
                    time.sleep(5)

            df = pd.DataFrame(all_results)

            self.logger.info(f"NGT Data fetched: {len(df)} rows")

            return df

        except Exception as e:
            self.logger.error(f"Error in NGT get_data: {e}", exc_info=True)
            return pd.DataFrame()