# app/ibbi.py

import re
import time
import requests
import pandas as pd
from bs4 import BeautifulSoup
from urllib.parse import quote_plus

from app.logger import get_global_logger
from app.konstant import get_api_config


class IBBI:

    def __init__(self):
        self.session = requests.Session()
        self.logger = get_global_logger()
        self.config = get_api_config()["ibbi"]

        self.base_site = self.config["base_site"]
        self.selectors = self.config["selectors"]
        self.regex_pdf = re.compile(self.config["regex"]["pdf"])

    # -------------------------
    # CORE PARSER
    # -------------------------
    def _extract_rows(self, soup):
        table = soup.select_one(self.selectors["table"])
        if not table:
            return []

        rows = table.find_all("tr")
        if len(rows) <= 1:
            return []

        results = []

        for row in rows[1:]:
            cols = [td.get_text(strip=True) for td in row.find_all("td")]

            link_tag = row.find(self.selectors["link"])
            pdf_link = ""

            if link_tag:
                onclick = link_tag.get("onclick", "")
                match = self.regex_pdf.search(onclick)

                if match:
                    pdf_link = self.base_site + match.group(1)

            if cols:
                cols.append(pdf_link)
                results.append(cols)

        return results

    # -------------------------
    # PAGINATION TYPE
    # -------------------------
    def _handle_pagination(self, section_name, section_config):
        page = 1
        all_rows = []

        while True:
            url = f"{self.base_site}{section_config['url']}?page={page}"
            self.logger.info(f"{section_name} → Page {page}")

            resp = self.session.get(url, verify=False)
            if resp.status_code != 200:
                break

            soup = BeautifulSoup(resp.text, "html.parser")
            rows = self._extract_rows(soup)

            if not rows:
                break

            for r in rows:
                r.insert(0, section_name)

            all_rows.extend(rows)

            page += 1
            time.sleep(1)

        return all_rows

    # -------------------------
    # COURT TYPE
    # -------------------------
    def _handle_courts(self, section_name, section_config):
        all_rows = []

        param = section_config["param"]

        for court in section_config["courts"]:
            page = 1

            while True:
                encoded = quote_plus(court)
                url = f"{self.base_site}{section_config['url']}?{param}={encoded}&page={page}"

                self.logger.info(f"{court} → Page {page}")

                resp = self.session.get(url, verify=False)
                if resp.status_code != 200:
                    break

                soup = BeautifulSoup(resp.text, "html.parser")
                rows = self._extract_rows(soup)

                if not rows:
                    break

                for r in rows:
                    r.insert(0, court)

                all_rows.extend(rows)

                page += 1
                time.sleep(1)

        return all_rows

    # -------------------------
    # MAIN ENTRY
    # -------------------------
    def get_data(self):
        results = {}

        for section_name, section_config in self.config["sections"].items():

            if section_config["type"] == "pagination":
                rows = self._handle_pagination(section_name, section_config)
                df = pd.DataFrame(rows)

                results[section_name] = df

            elif section_config["type"] == "court_wise":

                for court in section_config["courts"]:
                    rows = self._handle_single_court(section_config, court)
                    df = pd.DataFrame(rows)

                    key = f"high_court_{court.lower().replace(' ', '_')}"
                    results[key] = df

        return results